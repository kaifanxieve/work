"""
KFX Continuous Limit — Live 2D Visualisation 

State space: S^1 × Z2  (two circles: b=0 outer, b=1 inner)
Dynamics (per step):
- R1: (theta, b) -> (theta + omega, b)
- R2: (theta, b) -> (theta - omega, 1-b)

Controls:
  Space : pause/resume
  N     : single-step (when paused)
  R     : reset
  S     : save a snapshot (PNG)
  Q/Esc : quit
"""

import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation


class KFXContinuousSimulator:
    def __init__(self, m_equiv: int = 101, seed: int | None = None):
        """
        m_equiv: used only to set omega = 2*pi/m_equiv (so it matches the discrete intuition)
        """
        self.rng = np.random.default_rng(seed)
        self.m_equiv = max(3, int(m_equiv))
        self.omega = 2 * np.pi / self.m_equiv

        # Visual radii (two disjoint circles)
        self.r_outer = 1.0
        self.r_inner = 0.62

        self.reset()

    def reset(self):
        self.theta = 0.0
        self.b = 0  # 0 -> outer circle, 1 -> inner circle
        self.t = 0
        self.last_rule = None

        # Trail for drawing
        self.trail_xy = []
        self.trail_rules = []

    def step(self, p_r2: float = 0.50):
        """
        One step of dynamics.
        With probability p_r2 choose R2, else choose R1.
        """
        u = self.rng.random()
        if u < p_r2:
            # R2: theta -> theta - omega, b flips
            self.theta = (self.theta - self.omega) % (2 * np.pi)
            self.b = 1 - self.b
            self.last_rule = "R2"
        else:
            # R1: theta -> theta + omega, b stays
            self.theta = (self.theta + self.omega) % (2 * np.pi)
            self.last_rule = "R1"

        self.t += 1

        x, y = self.current_xy()
        self.trail_xy.append((x, y))
        self.trail_rules.append(self.last_rule)

    def current_xy(self):
        r = self.r_outer if self.b == 0 else self.r_inner
        return r * np.cos(self.theta), r * np.sin(self.theta)


def main():
    # ---------- Parameters you can tweak ----------
    m_equiv = 101          # affects omega = 2*pi/m_equiv
    p_r2 = 0.55            # probability of choosing R2 each step
    fps = 30               # animation update rate
    steps_per_frame = 2    # simulation steps per frame
    trail_len = 500        # how many trail points to show
    seed = None            # set an int for reproducibility
    # ---------------------------------------------

    sim = KFXContinuousSimulator(m_equiv=m_equiv, seed=seed)

    # Matplotlib figure
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(-1.25, 1.25)
    ax.set_ylim(-1.25, 1.25)
    ax.grid(True, alpha=0.25)
    ax.set_title("KFX Continuous Limit (S¹ × Z₂) — Live")

    # Draw the two circles (reference geometry)
    th = np.linspace(0, 2 * np.pi, 800)
    ax.plot(np.cos(th) * sim.r_outer, np.sin(th) * sim.r_outer, linestyle="--", linewidth=1)
    ax.plot(np.cos(th) * sim.r_inner, np.sin(th) * sim.r_inner, linestyle="--", linewidth=1)

    # Dynamic artists
    trail_line, = ax.plot([], [], linewidth=2, alpha=0.65)  # trail path
    point_scatter = ax.scatter([], [], s=90)                # current point

    info_text = ax.text(
        0.02, 0.98, "",
        transform=ax.transAxes,
        va="top", ha="left",
        fontsize=10,
        bbox=dict(boxstyle="round", alpha=0.15)
    )

    # Runtime state
    paused = {"value": False}
    single_step = {"value": False}
    snapshot_idx = {"value": 0}

    def format_info():
        circle = "outer (b=0)" if sim.b == 0 else "inner (b=1)"
        return (
            f"t = {sim.t}\n"
            f"m_equiv = {sim.m_equiv}\n"
            f"omega = 2π/m ≈ {sim.omega:.6f}\n"
            f"b = {sim.b}  -> {circle}\n"
            f"theta ≈ {sim.theta:.4f} rad\n"
            f"last rule: {sim.last_rule}\n"
            f"p(R2) = {p_r2:.2f}\n"
            f"{'PAUSED' if paused['value'] else 'RUNNING'}"
        )

    def on_key(event):
        key = (event.key or "").lower()
        if key == " ":
            paused["value"] = not paused["value"]
        elif key == "n":
            # only meaningful when paused
            single_step["value"] = True
            paused["value"] = True
        elif key == "r":
            sim.reset()
        elif key == "s":
            snapshot_idx["value"] += 1
            fname = f"kfx_snapshot_{snapshot_idx['value']:03d}.png"
            fig.savefig(fname, dpi=160, bbox_inches="tight")
            print(f"[saved] {fname}")
        elif key in ("escape", "q"):
            plt.close(fig)

    fig.canvas.mpl_connect("key_press_event", on_key)

    def init():
        trail_line.set_data([], [])
        point_scatter.set_offsets(np.array([[0.0, 0.0]]))
        info_text.set_text(format_info())
        return trail_line, point_scatter, info_text

    def update(_frame):
        # Decide whether to advance simulation
        do_step = (not paused["value"]) or single_step["value"]
        if do_step:
            for _ in range(steps_per_frame):
                sim.step(p_r2=p_r2)
            single_step["value"] = False

        # Prepare trail (truncate)
        trail = sim.trail_xy[-trail_len:]
        if len(trail) >= 2:
            xs = [p[0] for p in trail]
            ys = [p[1] for p in trail]
            trail_line.set_data(xs, ys)
        elif len(trail) == 1:
            trail_line.set_data([trail[0][0]], [trail[0][1]])
        else:
            trail_line.set_data([], [])

        # Current point
        x, y = sim.current_xy()
        point_scatter.set_offsets(np.array([[x, y]]))

        # Info text
        info_text.set_text(format_info())
        return trail_line, point_scatter, info_text

    interval_ms = int(1000 / max(1, fps))
    ani = FuncAnimation(
        fig, update, init_func=init,
        interval=interval_ms, blit=True
    )

    print("Controls: Space pause/resume | N single-step | R reset | S snapshot | Q/Esc quit")
    plt.show()


if __name__ == "__main__":
    main()