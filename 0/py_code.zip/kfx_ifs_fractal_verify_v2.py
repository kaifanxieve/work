# kfx_ifs_fractal_verify_v2.py
# ------------------------------------------------------------
# Verify Hausdorff / box-counting dimension of a 2-branch IFS attractor.
#
# IFS on x in [0,1):
#   F1(x,b) = (r*x, b)
#   F2(x,b) = (r*x + (1-r), 1-b)
#
# For r < 1/2, the two images are disjoint -> Open Set Condition holds.
# Then Hausdorff dimension s satisfies: 2 * r^s = 1 -> s = log(2)/log(1/r).
#
# We estimate box-counting dimension by counting occupied bins on each layer.
# ------------------------------------------------------------

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt


def chaos_game_points(r: float, n_points: int, seed: int = 0, burn_in: int = 500) -> np.ndarray:
    """
    Random iteration (chaos game) sampling of the attractor.
    Returns array shape (n_points, 2): columns are (b, x).
    """
    rng = np.random.default_rng(seed)
    x = 0.123456
    b = 0

    # burn-in
    for _ in range(burn_in):
        if rng.random() < 0.5:
            x = r * x
        else:
            x = r * x + (1 - r)
            b = 1 - b

    pts = np.empty((n_points, 2), dtype=float)
    for i in range(n_points):
        if rng.random() < 0.5:
            x = r * x
        else:
            x = r * x + (1 - r)
            b = 1 - b
        pts[i, 0] = b
        pts[i, 1] = x
    return pts


def boxcount_occupied(points: np.ndarray, Ks: list[int]) -> tuple[float, float, list[int]]:
    """
    Count occupied boxes N(K) on grid: b in {0,1}, x in [0,1) with K bins.
    Fit log N(K) = a + alpha log K.
    Returns: (alpha_hat, R2, N_list)
    """
    Ns = []
    for K in Ks:
        occ = np.zeros((2, K), dtype=np.uint8)
        xs = points[:, 1]
        bs = points[:, 0].astype(np.int64)

        idx = np.floor(xs * K).astype(np.int64)
        idx = np.clip(idx, 0, K - 1)
        occ[bs, idx] = 1

        N = int(occ.sum())
        Ns.append(N)
        print(f"[K={K}] occupied N(K) = {N} (max {2*K})")

    x = np.log(np.array(Ks, dtype=float))
    y = np.log(np.array(Ns, dtype=float))

    alpha_hat, intercept = np.polyfit(x, y, 1)

    # R^2
    y_pred = alpha_hat * x + intercept
    ss_res = float(np.sum((y - y_pred) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0

    return float(alpha_hat), float(r2), Ns


def main():
    r = 0.38
    alpha_theory = np.log(2.0) / np.log(1.0 / r)

    Ks = [256, 512, 1024, 2048, 4096, 8192]
    n_points = 300_000
    seeds = [0, 1, 2, 3, 4]   # repeat to show stability

    print("=== IFS Fractal Verification (v2) ===")
    print(f"r = {r}")
    print(f"Theoretical alpha = log 2 / log(1/r) = {alpha_theory:.6f}")
    print(f"Sample points per run = {n_points}")
    print(f"Ks = {Ks}")
    print(f"seeds = {seeds}\n")

    alpha_hats = []
    r2s = []

    for sd in seeds:
        print(f"--- seed={sd} ---")
        pts = chaos_game_points(r=r, n_points=n_points, seed=sd, burn_in=500)
        alpha_hat, r2, Ns = boxcount_occupied(pts, Ks)
        alpha_hats.append(alpha_hat)
        r2s.append(r2)
        print(f"Estimated alpha = {alpha_hat:.6f}   R^2 = {r2:.6f}\n")

    alpha_hats = np.array(alpha_hats, dtype=float)
    r2s = np.array(r2s, dtype=float)

    mean = float(np.mean(alpha_hats))
    std = float(np.std(alpha_hats, ddof=1)) if len(alpha_hats) > 1 else 0.0
    mean_r2 = float(np.mean(r2s))

    print("=== Summary ===")
    print(f"Theory alpha : {alpha_theory:.6f}")
    print(f"Mean alpha^ : {mean:.6f}  (std {std:.6f})")
    print(f"Mean R^2    : {mean_r2:.6f}")
    print(f"Abs error   : {abs(mean - alpha_theory):.6f}")

    # Plot last run log-log (optional)
    plt.figure(figsize=(6.8, 5.2))
    x = np.log(np.array(Ks, float))
    y = np.log(np.array(Ns, float))
    plt.plot(x, y, marker="o")
    plt.xlabel("log K")
    plt.ylabel("log N(K)")
    plt.title("Box-counting fit for reachable (visited) set")
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()