# polygon_to_circle_kfx.py
# ------------------------------------------------------------
# Visualize discrete m-gon -> continuous circle limit
# for KFX-style two-layer system (b=0 outer, b=1 inner)
# ------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt


def regular_ngon(m, radius=1.0, phase=0.0):
    """Vertices of a regular m-gon on a circle."""
    k = np.arange(m)
    theta = 2 * np.pi * k / m + phase
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    return x, y


def draw_case(ax, m):
    ax.set_aspect("equal")
    ax.set_xlim(-1.25, 1.25)
    ax.set_ylim(-1.25, 1.25)
    ax.grid(alpha=0.3)

    # radii for two layers
    r_outer = 1.0
    r_inner = 0.6

    # dashed reference circles
    t = np.linspace(0, 2*np.pi, 400)
    ax.plot(np.cos(t), np.sin(t),
            linestyle="--", color="red", alpha=0.3)
    ax.plot(r_inner*np.cos(t), r_inner*np.sin(t),
            linestyle="--", color="blue", alpha=0.3)

    if m == np.inf:
        # continuous limit
        ax.plot(np.cos(t), np.sin(t),
                color="red", lw=2.5, label="b=0 (outer)")
        ax.plot(r_inner*np.cos(t), r_inner*np.sin(t),
                color="blue", lw=2.5, label="b=1 (inner)")
        ax.set_title("Continuous Limit (Circle)")
        ax.legend(loc="upper right", fontsize=8)
        return

    # discrete polygons
    xo, yo = regular_ngon(m, r_outer)
    xi, yi = regular_ngon(m, r_inner, phase=np.pi/m)

    # close loops
    ax.plot(np.r_[xo, xo[0]], np.r_[yo, yo[0]],
            color="red", lw=2)
    ax.plot(np.r_[xi, xi[0]], np.r_[yi, yi[0]],
            color="blue", lw=2)

    # vertices
    ax.scatter(xo, yo, color="red", s=60, zorder=3)
    ax.scatter(xi, yi, color="blue", s=60, zorder=3)

    # light connections (show generator-style structure)
    for i in range(m):
        for j in range(m):
            ax.plot([xo[i], xi[j]],
                    [yo[i], yi[j]],
                    color="gray", alpha=0.15, lw=0.8)

    ax.set_title(f"m = {m}\n{m}-gon → Circle")


def main():
    ms = [3, 5, 7, 13, 101, np.inf]

    fig, axes = plt.subplots(2, 3, figsize=(14, 9))
    axes = axes.flatten()

    for ax, m in zip(axes, ms):
        draw_case(ax, m)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()