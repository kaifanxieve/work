# structural_falsifiability_search.py
# ============================================================
# Unified Executable Counterexample Search
# Covers:
#   F1 - Recoverability (Irreversibility)
#   F2 - Preference (Commitment-free continuation)
#   F3 - Non-bypassability
# ============================================================

from collections import deque

# ============================================================
# 1. STATE SPACE
# ============================================================

states = {
    "a1", "a2",      # fine antecedents
    "b",
    "good", "bad",
    "fail",
    "safe_exit"
}

# ============================================================
# 2. TRANSITIONS (Execution Dynamics)
# ============================================================

transitions = {
    "a1": ["b"],
    "a2": ["b"],
    "b": ["good", "bad"],        # branching after degradation
    # uncomment next line to introduce bypass (F3 violation)
    # "b": ["good", "bad", "safe_exit"],
    "good": ["fail"],
    "bad": ["fail"],
    "safe_exit": []
}

# ============================================================
# 3. DEGRADATION (many-to-one)
# ============================================================

degradation = {
    "a1": "A",
    "a2": "A",
    "b": "B",
    "good": "G",
    "bad": "D",
    "fail": "FAIL",
    "safe_exit": "SAFE"
}

# Build inverse image of degradation
inverse_degradation = {}
for s, c in degradation.items():
    inverse_degradation.setdefault(c, set()).add(s)

# ============================================================
# 4. EXECUTABLE CONSTRAINTS
# ============================================================

# ---- F1: recovery constraint ----
def executable_recovery(coarse_state, recovered_state):
    # Toggle this:
    # return True   -> recoverability allowed (F1 violated)
    return False    # recovery forbidden (F1 holds)


# ---- F2/F3: execution constraint ----
def executable(state):
    return True


# ============================================================
# 5. F1: RECOVERABILITY SEARCH
# ============================================================

def search_F1_recoverability():
    for coarse_state, candidates in inverse_degradation.items():
        if len(candidates) <= 1:
            continue
        for recovered in candidates:
            if executable_recovery(coarse_state, recovered):
                if degradation[recovered] == coarse_state:
                    return True, coarse_state, recovered
    return False, None, None


# ============================================================
# 6. F2: PREFERENCE (COMMITMENT-FREE CONTINUATION)
# ============================================================

def step_commitment_free(state_set):
    next_states = set()
    for s in state_set:
        for nxt in transitions.get(s, []):
            next_states.add(nxt)
    return next_states


def search_F2_preference(start_states, max_steps=5):
    current = set(start_states)

    for _ in range(max_steps):
        if not executable(current):
            return False

        nxt = step_commitment_free(current)

        # if forced collapse, preference is induced
        if len(nxt) <= 1:
            return False

        current = nxt

    # multiple futures maintained without commitment
    return True


# ============================================================
# 7. F3: NON-BYPASSABILITY SEARCH
# ============================================================

def search_F3_bypass(start_states, forbidden_state):
    visited = set()
    queue = deque(start_states)

    while queue:
        s = queue.popleft()

        if s in visited:
            continue
        visited.add(s)

        if not executable(s):
            continue

        if s == forbidden_state:
            continue

        for nxt in transitions.get(s, []):
            queue.append(nxt)

    return forbidden_state not in visited


# ============================================================
# 8. RUN ALL CHECKS
# ============================================================

if __name__ == "__main__":

    collapsed_antecedents = ["a1", "a2"]

    print("====================================")
    print("STRUCTURAL FALSIFIABILITY SEARCH")
    print("====================================\n")

    # ---------- F1 ----------
    f1, coarse, recovered = search_F1_recoverability()
    print("[F1] Recoverability")
    if f1:
        print("  Recoverability exists: True")
        print(f"  => F1 violated: '{coarse}' recovered as '{recovered}'")
    else:
        print("  Recoverability exists: False")
        print("  => F1 holds: Irreversibility satisfied")
    print()

    # ---------- F2 ----------
    f2 = search_F2_preference(collapsed_antecedents)
    print("[F2] Preference")
    if f2:
        print("  Commitment-free continuation exists: True")
        print("  => F2 violated: Preference NOT structurally forced")
    else:
        print("  Commitment-free continuation exists: False")
        print("  => F2 holds: Preference structurally induced")
    print()

    # ---------- F3 ----------
    f3 = search_F3_bypass(collapsed_antecedents, "fail")
    print("[F3] Non-bypassability")
    if f3:
        print("  Bypass exists: True")
        print("  => F3 violated: Non-bypassability FAILS")
    else:
        print("  Bypass exists: False")
        print("  => F3 holds: No executable bypass path found")
    print("\n====================================")