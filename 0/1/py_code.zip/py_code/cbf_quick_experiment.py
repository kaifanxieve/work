# cbf_quick_experiment.py
# ------------------------------------------------------------
# QUICK CBF EXPERIMENT (3–5 minutes)
# Purpose:
#   Minimal but adversarial validation of nominal vs robust CBF
#   No training, no tuning, no stochastic luck
# ------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt
import csv
from dataclasses import dataclass
from typing import Optional

# ============================================================
# Utilities
# ============================================================

def norm(v):
    return float(np.linalg.norm(v))

def unit(v):
    n = norm(v)
    if n < 1e-12:
        return np.zeros_like(v)
    return v / n

def clip_ball(v, umax):
    n = norm(v)
    if n <= umax or n == 0.0:
        return v
    return v * (umax / n)

def proj_halfspace(u, a, rhs):
    # project u onto a^T u >= rhs
    if float(a @ u) >= rhs:
        return u
    denom = float(a @ a)
    if denom < 1e-12:
        return u
    return u + ((rhs - float(a @ u)) / denom) * a


# ============================================================
# CBF controllers (h(x) = 1 - ||x||^2)
# ============================================================

def nominal_cbf_u(x, u_des, alpha, umax):
    h = 1.0 - float(x @ x)
    a = -2.0 * x
    rhs = -alpha * h
    u = proj_halfspace(u_des, a, rhs)
    return clip_ball(u, umax)

def robust_cbf_u(x, u_des, alpha, umax, wmax):
    h = 1.0 - float(x @ x)
    a = -2.0 * x
    rhs = -alpha * h + 2.0 * norm(x) * wmax
    u = proj_halfspace(u_des, a, rhs)
    return clip_ball(u, umax)


# ============================================================
# Worst-case disturbance (outward)
# ============================================================

def disturbance(x, wmax):
    if wmax <= 0:
        return np.zeros_like(x)
    d = unit(x) if norm(x) > 1e-12 else unit(np.random.normal(size=x.shape))
    return wmax * d


# ============================================================
# Simulation
# ============================================================

@dataclass
class SimResult:
    out_time: Optional[float]
    max_norm: float
    min_h: float
    traj_norm: np.ndarray
    traj_h: np.ndarray

def simulate(
    controller,
    T=3.0,
    dt=5e-4,
    alpha=5.0,
    umax=1.0,
    wmax=0.6,
    k_des=0.5,
    seed=0
):
    rng = np.random.default_rng(seed)
    steps = int(T / dt)

    # start near boundary
    x = 0.995 * unit(rng.normal(size=(2,)))

    traj_norm = np.zeros(steps)
    traj_h = np.zeros(steps)

    out_time = None
    maxn = norm(x)
    minh = 1.0 - float(x @ x)

    for i in range(steps):
        t = i * dt
        u_des = -k_des * x

        if controller == "nominal":
            u = nominal_cbf_u(x, u_des, alpha, umax)
        elif controller == "robust":
            u = robust_cbf_u(x, u_des, alpha, umax, wmax)
        else:
            raise ValueError

        w = disturbance(x, wmax)
        x = x + dt * (u + w)

        nx = norm(x)
        h = 1.0 - float(x @ x)

        traj_norm[i] = nx
        traj_h[i] = h

        maxn = max(maxn, nx)
        minh = min(minh, h)

        if out_time is None and nx > 1.0:
            out_time = t

    return SimResult(out_time, maxn, minh, traj_norm, traj_h)


# ============================================================
# QUICK EXPERIMENT
# ============================================================

def run_quick_experiment():
    # ---- fixed "hard" parameters ----
    alpha = 5.0
    dt = 5e-4
    k_des = 0.5
    wmax = 0.6
    umax_list = [0.5, 1.0]   # infeasible vs feasible
    controllers = ["nominal", "robust"]
    seeds = range(10)

    rows = []
    reps = []

    for umax in umax_list:
        for ctrl in controllers:
            outs = 0
            minhs = []

            for seed in seeds:
                r = simulate(
                    controller=ctrl,
                    alpha=alpha,
                    dt=dt,
                    umax=umax,
                    wmax=wmax,
                    k_des=k_des,
                    seed=seed
                )
                if r.out_time is not None:
                    outs += 1
                minhs.append(r.min_h)

                if seed == 0:
                    reps.append((ctrl, umax, r))

            rows.append({
                "controller": ctrl,
                "umax": umax,
                "wmax": wmax,
                "out_rate": outs / len(seeds),
                "worst_min_h": min(minhs)
            })

    # save CSV
    with open("cbf_quick_results.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    print("Saved: cbf_quick_results.csv")

    # plot ||x||
    plt.figure()
    for ctrl, umax, r in reps:
        t = np.arange(len(r.traj_norm)) * dt
        plt.plot(t, r.traj_norm, label=f"{ctrl}, umax={umax}")
    plt.axhline(1.0)
    plt.xlabel("t (s)")
    plt.ylabel("||x(t)||")
    plt.legend()
    plt.tight_layout()
    plt.savefig("quick_traj_norm.png", dpi=200)
    print("Saved: quick_traj_norm.png")

    # plot h(x)
    plt.figure()
    for ctrl, umax, r in reps:
        t = np.arange(len(r.traj_h)) * dt
        plt.plot(t, r.traj_h, label=f"{ctrl}, umax={umax}")
    plt.axhline(0.0)
    plt.xlabel("t (s)")
    plt.ylabel("h(x(t))")
    plt.legend()
    plt.tight_layout()
    plt.savefig("quick_traj_h.png", dpi=200)
    print("Saved: quick_traj_h.png")

    print("\nSummary:")
    for r in rows:
        print(
            f"  {r['controller']:7s} | umax={r['umax']:.1f} | "
            f"out_rate={r['out_rate']:.2f} | worst_min_h={r['worst_min_h']:.3f}"
        )


if __name__ == "__main__":
    run_quick_experiment()