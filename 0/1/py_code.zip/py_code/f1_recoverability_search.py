# f1_recoverability_search.py
# ============================================================
# Counterexample Search for F1 (Recoverability)
#
# Purpose:
#   Check whether a many-to-one degradation admits an
#   executable recovery (right-inverse).
#
# Interpretation:
#   - If recoverability exists  -> F1 violated
#   - If no recoverability      -> F1 holds (irreversibility)
# ============================================================


# ============================================================
# 1. Fine-scale state space
# ============================================================

fine_states = {
    "a1", "a2",   # collapsed antecedents
    "b"
}


# ============================================================
# 2. Degradation mapping (many-to-one)
# ============================================================

# a1, a2 collapse to the same coarse state A
degradation = {
    "a1": "A",
    "a2": "A",
    "b":  "B",
}

# Build inverse image: coarse_state -> {fine_states}
inverse_degradation = {}
for fine, coarse in degradation.items():
    inverse_degradation.setdefault(coarse, set()).add(fine)


# ============================================================
# 3. Executable constraint on recovery
# ============================================================

def executable_recovery(coarse_state, recovered_state):
    """
    Executable constraint for recovery.

    Toggle behavior here:

    - return True:
        recovery is allowed (F1 likely violated)

    - return False:
        recovery is forbidden (F1 holds)
    """

    # ---- CASE 1: recovery allowed ----
    # return True

    # ---- CASE 2: recovery forbidden ----
    return False


# ============================================================
# 4. F1 counterexample search
# ============================================================

def search_recoverability():
    """
    Search for an executable right-inverse of degradation.

    Returns:
        (exists, coarse_state, recovered_state)
    """

    for coarse_state, fine_candidates in inverse_degradation.items():

        # Only interesting if collapse occurred
        if len(fine_candidates) <= 1:
            continue

        for recovered in fine_candidates:

            # Check executable constraint
            if not executable_recovery(coarse_state, recovered):
                continue

            # Check right-inverse condition
            if degradation[recovered] == coarse_state:
                return True, coarse_state, recovered

    return False, None, None


# ============================================================
# 5. Run search
# ============================================================

if __name__ == "__main__":

    print("====================================")
    print("Counterexample Search Result (F1)")
    print("====================================")

    exists, coarse, recovered = search_recoverability()

    if exists:
        print("Recoverability exists: True")
        print(f"=> F1 violated: coarse state '{coarse}' "
              f"can be recovered as '{recovered}'.")
    else:
        print("Recoverability exists: False")
        print("=> F1 holds: No executable recovery operation found.")