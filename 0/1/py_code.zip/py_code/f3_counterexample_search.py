# counterexample_search.py
# -----------------------------------------
# Finite Transition System Counterexample Search
# Focus: F3 Non-bypassability
# -----------------------------------------

from collections import deque

# =================================================
# 1. Define State Space
# =================================================
states = {
    "a1", "a2",        # fine-scale antecedents
    "b", "c",
    "fail",            # undesirable consequence
    "safe_exit"        # optional bypass state
}

# =================================================
# 2. Define Transitions (Execution Dynamics)
# =================================================
transitions = {
    "a1": ["b"],
    "a2": ["b"],
    "b": ["c"],              # normal path
    # uncomment next line to CREATE a bypass
    # "b": ["c", "safe_exit"],
    "c": ["fail"],
    "safe_exit": []          # terminal safe state
}

# =================================================
# 3. Degradation Mapping (many-to-one collapse)
# =================================================
# a1, a2 are collapsed and indistinguishable
degradation = {
    "a1": "A",
    "a2": "A",
    "b": "B",
    "c": "C",
    "fail": "FAIL",
    "safe_exit": "SAFE"
}

# =================================================
# 4. Executable Constraint
# =================================================
def executable(state):
    """
    Executable constraint.
    Modify this to restrict access, memory, or operations.
    """
    return True


# =================================================
# 5. Bypass Search Algorithm (F3)
# =================================================
def has_bypass(start_states, forbidden_state):
    """
    Breadth-first search:
    Is there a reachable execution path that avoids forbidden_state?
    """
    visited = set()
    queue = deque(start_states)

    while queue:
        current = queue.popleft()

        if current in visited:
            continue
        visited.add(current)

        if not executable(current):
            continue

        # forbidden consequence reached
        if current == forbidden_state:
            continue

        for nxt in transitions.get(current, []):
            queue.append(nxt)

    return forbidden_state not in visited


# =================================================
# 6. Run Counterexample Check
# =================================================
if __name__ == "__main__":

    # antecedents collapsed by degradation
    collapsed_antecedents = ["a1", "a2"]

    forbidden = "fail"

    bypass_exists = has_bypass(collapsed_antecedents, forbidden)

    print("====================================")
    print("Counterexample Search Result (F3)")
    print("====================================")
    print("Bypass exists:", bypass_exists)

    if bypass_exists:
        print("=> F3 violated: Non-bypassability FAILS in this system.")
    else:
        print("=> F3 holds: No executable bypass path found.")