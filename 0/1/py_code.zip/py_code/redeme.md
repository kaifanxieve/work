# Structural Falsifiability & CBF Bypass Demo

This ZIP contains **executable counterexample searches** and **adversarial simulations** supporting structural falsifiability claims (F1–F3) and demonstrating **CBF bypass under disturbance and actuation limits**.

No training. No learning. No tuning tricks.

---

## Contents

### Control Barrier Function (CBF) Experiments

- **`cbf_quick_experiment.py`**  
  Minimal 3–5 minute experiment.  
  Compares *nominal* vs *robust* CBF under worst-case outward disturbance.  
  Produces:
  - `cbf_quick_results.csv`
  - `quick_traj_norm.png`
  - `quick_traj_h.png`

- **`cbf_bypass_demo.py`**  
  Full parameter sweep over:
  - barrier gain `alpha`
  - timestep `dt`
  - actuation limit `umax`
  - disturbance bound `wmax`
  - disturbance modes (outward / random / switching / biased)  
  Produces:
  - `cbf_sweep_results.csv`
  - `traj_norm.png`
  - `traj_h.png`

Purpose: show **non-bypassability failure** of nominal CBF under bounded disturbance and actuator saturation, and the limits of robust sufficient conditions.

---

### Structural Falsifiability Counterexample Searches

All searches are **finite, executable, and constructive**.

- **`f1_recoverability_search.py`**  
  Tests **F1 (Irreversibility)**:  
  whether a many-to-one degradation admits an executable right-inverse.

- **`f2_preference_counterexample.py`**  
  Tests **F2 (Preference Emergence)**:  
  whether commitment-free continuation can avoid forced preference.

- **`f3_counterexample_search.py`**  
  Tests **F3 (Non-bypassability)**:  
  whether an executable path exists that avoids a forbidden consequence.

- **`structural_falsifiability_search.py`**  
  Unified checker for F1–F3 in a single transition system.  
  Toggle transitions or executable constraints to generate violations.

---

### Robust / Perturbed Falsifiability

- **`pseudocode.md`**  
  Robust extension of F1–F4:  
  searches counterexamples under bounded perturbations of
  - degradation mappings
  - executable constraints

Goal: falsifiability that survives **small modelling errors**, not idealised assumptions.

---

## Requirements

- Python ≥ 3.9  
- `numpy`, `matplotlib`

No GPUs. No ML frameworks.

---

## How to Run

```bash
python cbf_quick_experiment.py
python cbf_bypass_demo.py

python f1_recoverability_search.py
python f2_preference_counterexample.py
python f3_counterexample_search.py
python structural_falsifiability_search.py