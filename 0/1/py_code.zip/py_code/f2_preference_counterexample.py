# f2_preference_counterexample.py
# --------------------------------------------------
# Counterexample Search for F2 (Preference)
# --------------------------------------------------

from collections import deque

# ==================================================
# 1. State space
# ==================================================
states = {
    "a1", "a2",           # fine antecedents
    "b",                  # collapsed state
    "good", "bad"         # divergent outcomes
}

# ==================================================
# 2. Transitions
# ==================================================
transitions = {
    "a1": ["b"],
    "a2": ["b"],
    "b": ["good", "bad"],   # branching after degradation
    "good": [],
    "bad": []
}

# ==================================================
# 3. Degradation mapping (many-to-one)
# ==================================================
degradation = {
    "a1": "A",
    "a2": "A",
    "b": "B",
    "good": "G",
    "bad": "D"
}

# ==================================================
# 4. Executable constraint
# ==================================================
def executable(state_set):
    """
    Executable constraint for continuation semantics.
    Here we allow maintaining a *set* of possible states.
    """
    return True


# ==================================================
# 5. Commitment-free continuation semantics
# ==================================================
def step(state_set):
    """
    One execution step under commitment-free semantics:
    propagate all possible futures without selecting one.
    """
    next_states = set()
    for s in state_set:
        for nxt in transitions.get(s, []):
            next_states.add(nxt)
    return next_states


# ==================================================
# 6. F2 Counterexample Search
# ==================================================
def preference_counterexample(start_states, max_steps=5):
    """
    Search for continuation without commitment.
    Returns True if F2 is violated (preference not forced).
    """
    current = set(start_states)

    for _ in range(max_steps):
        if not executable(current):
            return False

        nxt = step(current)

        # Commitment-free condition:
        # more than one future remains possible
        if len(nxt) > 1:
            current = nxt
        else:
            # forced collapse -> preference emerges
            return False

    # If we maintained multiple futures throughout
    return True


# ==================================================
# 7. Run search
# ==================================================
if __name__ == "__main__":

    collapsed_antecedents = ["a1", "a2"]

    violation = preference_counterexample(collapsed_antecedents)

    print("====================================")
    print("Counterexample Search Result (F2)")
    print("====================================")
    print("Preference violated (commitment-free continuation exists):", violation)

    if violation:
        print("=> F2 violated: Preference is NOT structurally forced.")
    else:
        print("=> F2 holds: Preference is structurally forced.")