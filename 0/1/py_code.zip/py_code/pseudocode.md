The falsifiability conditions F1--F4 can be operationalised as decision problems
over a chosen system class (e.g., finite transition systems).
To avoid reliance on idealised assumptions, we consider a robustness margin
with respect to both degradation mappings and executable constraints.

Specifically, we introduce bounded perturbations to the degradation mapping
(e.g., approximate many-to-one collapse) and to executable constraints
(e.g., limited additional memory or access).
We then search for executable counterexamples that satisfy the perturbed
conditions of F1--F4.

If no counterexample exists within a specified robustness margin, the
corresponding structural claim is not only unfalsified for the nominal model,
but remains unfalsified under small admissible perturbations.



Input:
  - State space S
  - Transition relation T
  - Degradation mapping π : S → S_c
  - Executable constraint set C
  - Robustness margins (ε, δ)

Output:
  - Counterexample for F1–F4, or NONE

Procedure RobustSearch:

1. Generate perturbed degradation mappings Π_ε
   such that each π' ∈ Π_ε deviates from π by at most ε
   (e.g., approximate collapse or partial distinguishability).

2. Generate perturbed executable constraints C_δ
   allowing bounded relaxation (e.g., limited extra memory or access).

3. For each (π', C') in Π_ε × C_δ:

   a. Check F1 (Robust Recoverability):
      Search for an admissible executable operation under C'
      that approximately inverts π'.
      If found, return counterexample to irreversibility.

   b. Check F2 (Robust Non-Commitment):
      Search for a continuation semantics under C'
      that preserves multiple futures without commitment.
      If found, return counterexample to preference emergence.

   c. Check F3 (Robust Bypassability):
      Search for an admissible bypass path that avoids the
      downstream consequences of π' under C'.
      If found, return counterexample to non-bypassability.

   d. Check F4 (Robust Responsibility Failure):
      If forced selection holds but a commitment-free continuation
      exists under C', return counterexample to responsibility.

4. If no counterexample is found for all perturbations,
   return NONE.