import numpy as np
import matplotlib.pyplot as plt
import csv
from dataclasses import dataclass
from typing import Dict, Tuple, List, Optional

# -----------------------------
# Utilities
# -----------------------------
def norm(v: np.ndarray) -> float:
    return float(np.linalg.norm(v))

def unit(v: np.ndarray) -> np.ndarray:
    n = norm(v)
    if n < 1e-12:
        return np.zeros_like(v)
    return v / n

def clip_ball(v: np.ndarray, umax: float) -> np.ndarray:
    n = norm(v)
    if n <= umax or n == 0.0:
        return v
    return v * (umax / n)

def proj_halfspace(u: np.ndarray, a: np.ndarray, rhs: float) -> np.ndarray:
    """
    Project u onto half-space a^T u >= rhs (Euclidean projection onto boundary if violated).
    """
    if float(a @ u) >= rhs:
        return u
    denom = float(a @ a)
    if denom < 1e-12:
        return u
    return u + ((rhs - float(a @ u)) / denom) * a

# -----------------------------
# CBF Controllers (for h(x)=1-||x||^2)
# -----------------------------
def nominal_cbf_u(x: np.ndarray, u_des: np.ndarray, alpha: float, umax: float) -> np.ndarray:
    """
    Nominal CBF for xdot = u (ignores w).
    Constraint: -2 x^T u + alpha(1-||x||^2) >= 0
    => (-2x)^T u >= -alpha(1-||x||^2)
    """
    h = 1.0 - float(x @ x)
    a = -2.0 * x
    rhs = -alpha * h
    u = proj_halfspace(u_des, a, rhs)
    u = clip_ball(u, umax)
    return u

def robust_cbf_u(x: np.ndarray, u_des: np.ndarray, alpha: float, umax: float, wmax: float) -> np.ndarray:
    """
    Robust sufficient CBF for xdot = u + w, ||w||<=wmax:
      -2 x^T u + alpha(1-||x||^2) - 2||x|| wmax >= 0
    => (-2x)^T u >= -alpha(1-||x||^2) + 2||x||wmax
    """
    h = 1.0 - float(x @ x)
    a = -2.0 * x
    rhs = -alpha * h + 2.0 * norm(x) * wmax
    u = proj_halfspace(u_des, a, rhs)
    u = clip_ball(u, umax)
    return u

# -----------------------------
# Disturbance models
# -----------------------------
def disturbance(x: np.ndarray, wmax: float, mode: str, rng: np.random.Generator, t: float) -> np.ndarray:
    """
    Different disturbance modes to avoid "hand-crafted" accusations.
    All satisfy ||w|| <= wmax.
    modes:
      - "outward": worst-case outward normal (adversarial bypass)
      - "random": random direction each step
      - "switching": switches between outward and random every 0.1s
      - "biased": random but biased outward (more realistic than pure adversary)
    """
    if wmax <= 0:
        return np.zeros_like(x)

    nx = norm(x)
    outward = unit(x) if nx > 1e-12 else unit(rng.normal(size=x.shape))

    if mode == "outward":
        d = outward
    elif mode == "random":
        d = unit(rng.normal(size=x.shape))
    elif mode == "switching":
        if int(t / 0.1) % 2 == 0:
            d = outward
        else:
            d = unit(rng.normal(size=x.shape))
    elif mode == "biased":
        # convex mixture: 70% outward + 30% random (then renormalize)
        d = 0.7 * outward + 0.3 * unit(rng.normal(size=x.shape))
        d = unit(d)
    else:
        raise ValueError(f"Unknown disturbance mode: {mode}")

    return wmax * d

# -----------------------------
# Simulation
# -----------------------------
@dataclass
class SimResult:
    out_time: Optional[float]
    max_norm: float
    min_h: float
    x_final: np.ndarray
    traj_norm: np.ndarray
    traj_h: np.ndarray

def simulate(
    controller: str,
    disturbance_mode: str,
    n: int = 2,
    T: float = 3.0,
    dt: float = 5e-4,
    alpha: float = 5.0,
    umax: float = 1.0,
    wmax: float = 0.6,
    k_des: float = 0.5,
    x0: Optional[np.ndarray] = None,
    seed: int = 0
) -> SimResult:
    rng = np.random.default_rng(seed)
    steps = int(T / dt)

    if x0 is None:
        # near boundary, random direction
        d = unit(rng.normal(size=(n,)))
        x = 0.995 * d
    else:
        x = x0.astype(float).copy()

    traj_norm = np.zeros(steps)
    traj_h = np.zeros(steps)

    out_time = None
    maxn = norm(x)
    minh = 1.0 - float(x @ x)

    for i in range(steps):
        t = i * dt
        # desired stabilising control
        u_des = -k_des * x

        if controller == "nominal":
            u = nominal_cbf_u(x, u_des, alpha, umax)
        elif controller == "robust":
            u = robust_cbf_u(x, u_des, alpha, umax, wmax)
        else:
            raise ValueError("controller must be 'nominal' or 'robust'")

        w = disturbance(x, wmax, disturbance_mode, rng, t)

        # Euler integration
        x = x + dt * (u + w)

        h = 1.0 - float(x @ x)
        nx = norm(x)

        traj_norm[i] = nx
        traj_h[i] = h

        maxn = max(maxn, nx)
        minh = min(minh, h)

        if out_time is None and nx > 1.0:
            out_time = t

    return SimResult(out_time, maxn, minh, x, traj_norm, traj_h)

# -----------------------------
# Experiment sweep + plots
# -----------------------------
def sweep_and_report():
    # Parameter grids (enough to show it's not "fine-tuned")
    alphas = [1.0, 2.0, 5.0, 10.0]
    dts = [1e-3, 5e-4]
    kdes = [0.2, 0.5, 1.0]
    umax_list = [0.5, 0.8, 1.0, 1.2]
    wmax_list = [0.2, 0.4, 0.6, 0.9]
    modes = ["outward", "random", "switching", "biased"]
    seeds = list(range(20))  # increase to 50/100 if you want

    T = 3.0
    n = 2

    rows = []
    # Representative trajectories for figure
    reps: List[Tuple[str, str, Dict, SimResult]] = []

    for alpha in alphas:
        for dt in dts:
            for k_des in kdes:
                for umax in umax_list:
                    for wmax in wmax_list:
                        for mode in modes:
                            for controller in ["nominal", "robust"]:
                                outs = 0
                                out_times = []
                                min_hs = []
                                for seed in seeds:
                                    r = simulate(
                                        controller=controller,
                                        disturbance_mode=mode,
                                        n=n, T=T, dt=dt,
                                        alpha=alpha,
                                        umax=umax,
                                        wmax=wmax,
                                        k_des=k_des,
                                        x0=None,
                                        seed=seed
                                    )
                                    if r.out_time is not None:
                                        outs += 1
                                        out_times.append(r.out_time)
                                    min_hs.append(r.min_h)

                                rate = outs / len(seeds)
                                mean_out = float(np.mean(out_times)) if out_times else np.nan
                                worst_min_h = float(np.min(min_hs))

                                rows.append({
                                    "controller": controller,
                                    "mode": mode,
                                    "alpha": alpha,
                                    "dt": dt,
                                    "k_des": k_des,
                                    "umax": umax,
                                    "wmax": wmax,
                                    "out_rate": rate,
                                    "mean_out_time": mean_out,
                                    "worst_min_h": worst_min_h
                                })

                                # store a few representative cases for plotting
                                if (alpha, dt, k_des, umax, wmax, mode) in [
                                    (5.0, 5e-4, 0.5, 1.0, 0.6, "outward"),
                                    (5.0, 5e-4, 0.5, 1.0, 0.6, "random"),
                                    (5.0, 5e-4, 0.5, 0.5, 0.6, "outward"),  # umax<wmax infeasible
                                ] and controller in ["nominal", "robust"]:
                                    # rerun with fixed seed for consistent figure
                                    rr = simulate(controller, mode, n=n, T=T, dt=dt, alpha=alpha,
                                                  umax=umax, wmax=wmax, k_des=k_des, seed=0)
                                    reps.append((controller, mode,
                                                 {"alpha":alpha,"dt":dt,"k_des":k_des,"umax":umax,"wmax":wmax},
                                                 rr))

    # Write CSV
    with open("cbf_sweep_results.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print("Saved: cbf_sweep_results.csv (sweep statistics)")

    # Plot representative trajectories: ||x(t)|| and h(t)
    # 1) norm plot
    plt.figure()
    for controller, mode, p, r in reps:
        label = f"{controller}-{mode} (umax={p['umax']}, wmax={p['wmax']})"
        t = np.arange(len(r.traj_norm)) * p["dt"]
        plt.plot(t, r.traj_norm, label=label)
    plt.axhline(1.0)
    plt.xlabel("t (s)")
    plt.ylabel("||x(t)||")
    plt.legend()
    plt.title("Representative trajectories (safety boundary at ||x||=1)")
    plt.tight_layout()
    plt.savefig("traj_norm.png", dpi=200)
    print("Saved: traj_norm.png")

    # 2) h plot
    plt.figure()
    for controller, mode, p, r in reps:
        label = f"{controller}-{mode} (umax={p['umax']}, wmax={p['wmax']})"
        t = np.arange(len(r.traj_h)) * p["dt"]
        plt.plot(t, r.traj_h, label=label)
    plt.axhline(0.0)
    plt.xlabel("t (s)")
    plt.ylabel("h(x(t)) = 1 - ||x(t)||^2")
    plt.legend()
    plt.title("Barrier evolution (boundary at h=0)")
    plt.tight_layout()
    plt.savefig("traj_h.png", dpi=200)
    print("Saved: traj_h.png")

    # Summarise a key slice: outward mode, alpha=5, dt=5e-4, k_des=0.5
    def match(row):
        return (row["mode"]=="outward" and row["alpha"]==5.0 and row["dt"]==5e-4 and row["k_des"]==0.5)

    slice_rows = [r for r in rows if match(r)]
    # sort for readability
    slice_rows.sort(key=lambda r: (r["controller"], r["umax"], r["wmax"]))
    print("\nKey slice (outward, alpha=5, dt=5e-4, k_des=0.5): out_rate")
    for r in slice_rows:
        print(f"  {r['controller']:7s} umax={r['umax']:.1f} wmax={r['wmax']:.1f} out_rate={r['out_rate']:.2f}")

if __name__ == "__main__":
    sweep_and_report()