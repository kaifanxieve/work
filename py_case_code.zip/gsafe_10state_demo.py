from itertools import combinations

# =====================================================
# 1. System definition
# =====================================================

# Finite state space X
X = list(range(10))

# Responsibility mapping rho: X -> R
rho = {
    0: 'A', 1: 'A', 2: 'A',
    3: 'B', 4: 'B', 5: 'B',
    6: 'C', 7: 'C', 8: 'C', 9: 'C'
}

# Global parameters (LOCKED to spec)
r = 2           # responsibility domain upper bound
epsilon = 0.5   # bias threshold (non-expansion constraint)
b = 10          # syntactic complexity budget

# Initial criterion set
P = []          # empty at the first step


# =====================================================
# 2. Disjunctive criterion p_S
# =====================================================

def criterion(S, x):
    """Disjunctive criterion: p_S(x) = 1 iff x in S"""
    return 1 if x in S else 0


def complexity(S):
    """
    Syntactic complexity of a pure disjunction:
    C(p_S) = |S| atomic nodes + (|S|-1) OR nodes
           = 2|S| - 1
    """
    return 2 * len(S) - 1


def responsibility_set(S):
    """Resp(p) = { rho(i) | i in S }"""
    return set(rho[i] for i in S)


# =====================================================
# 3. Equivalence classes induced by P
# =====================================================

def equivalence_classes(P):
    """
    Partition X according to the encoding induced by P.
    If P is empty, all states belong to one equivalence class.
    """
    if not P:
        return [set(X)]

    classes = {}
    for x in X:
        code = tuple(p(x) for p in P)
        classes.setdefault(code, set()).add(x)
    return list(classes.values())


# =====================================================
# 4. Bias and non-expansion constraint
# =====================================================

def beta(c, S):
    """
    Bias of criterion p_S on equivalence class c.
    """
    c1 = sum(1 for x in c if x in S)
    c0 = len(c) - c1
    return abs(c1 - c0) / len(c)


def max_bias(P, S):
    """B(P, S) = max_c beta(c, S)"""
    return max(beta(c, S) for c in equivalence_classes(P))


# =====================================================
# 5. Accept predicate (STRICT)
# =====================================================

def accept(P, S):
    """
    Accept(P, p_S) iff:
    1. complexity <= b
    2. |Resp(p_S)| <= r
    3. B(P, p_S) <= epsilon
    """
    if complexity(S) > b:
        return False
    if len(responsibility_set(S)) > r:
        return False
    if max_bias(P, S) > epsilon:
        return False
    return True


def score(P, S):
    """Lexicographic score J(P, S)"""
    return (complexity(S),
            len(responsibility_set(S)),
            max_bias(P, S))


# =====================================================
# 6. Candidate enumeration
# =====================================================

def candidate_sets():
    """
    Enumerate candidate sets S in increasing |S|,
    respecting the complexity budget.
    """
    max_k = (b + 1) // 2  # from 2k-1 <= b
    for k in range(1, max_k + 1):
        for S in combinations(X, k):
            yield set(S)


# =====================================================
# 7. Run G_safe once (first step)
# =====================================================

accepted = []

for S in candidate_sets():
    if accept(P, S):
        accepted.append(S)
    if len(accepted) >= 3:
        break


print("First three acceptable criteria:\n")

for i, S in enumerate(accepted, 1):
    print(f"p{i}: S = {sorted(S)}")
    print("  Accept =", accept(P, S))
    print("  J =", score(P, S))
    print()

best = min(accepted, key=lambda S: score(P, S))

print("Selected p*:")
print("S* =", sorted(best))
print("J* =", score(P, best))
