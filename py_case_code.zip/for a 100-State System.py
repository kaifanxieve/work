from typing import List, Tuple, Callable, Dict, Set

# ============================================================
# 1. BASIC INPUT DEFINITIONS
# ============================================================

# State space: X = {0, 1, ..., 99}
X = list(range(100))

# Responsibility-domain mapping ρ : X → R
# This is an example mapping: 4 responsibility domains,
# each covering 25 consecutive states.
# You can replace this with any other deterministic mapping.
def rho(x: int) -> str:
    if 0 <= x <= 24:
        return "A"
    elif 25 <= x <= 49:
        return "B"
    elif 50 <= x <= 74:
        return "C"
    else:
        return "D"

# Global parameters (from the formal model)
r = 2           # maximum number of responsibility domains per criterion
epsilon = 0.5   # non-expansion (Beta) threshold
b = 10          # complexity budget (irrelevant here because intervals are atomic)

# ============================================================
# 2. CRITERION DEFINITION (INTERVAL-BASED)
# ============================================================

# A criterion p_{u,v} is defined as:
#   p(x) = 1  if u <= x <= v
#        = 0  otherwise
#
# This corresponds to the optimized candidate domain H_int.
def interval_predicate(u: int, v: int) -> Callable[[int], int]:
    return lambda x: 1 if u <= x <= v else 0

# ============================================================
# 3. ACCEPT-CONDITION COMPONENTS
# ============================================================

def resp_set(u: int, v: int) -> Set[str]:
    """
    Compute Resp(p):
    the set of responsibility domains touched by interval [u, v].
    """
    return {rho(x) for x in range(u, v + 1)}

def beta_for_interval(
    u: int,
    v: int,
    equivalence_classes: List[List[int]]
) -> float:
    """
    Compute Beta(P, p_{u,v}).

    For each equivalence class c induced by the current criterion set P,
    compute the imbalance caused by p_{u,v}, and return the maximum.
    """
    beta_values = []

    for cls in equivalence_classes:
        # Number of states in this class selected by the interval
        c1 = sum(1 for x in cls if u <= x <= v)
        # Number of states not selected
        c0 = len(cls) - c1

        if len(cls) > 0:
            beta_values.append(abs(c1 - c0) / len(cls))

    # If there are no classes (degenerate case), Beta = 0
    return max(beta_values) if beta_values else 0.0

# ============================================================
# 4. THE OPTIMIZED G_safe OPERATOR
# ============================================================

def G_safe_interval(
    P: List[Callable[[int], int]]
) -> Tuple[Tuple[int, int], Tuple[int, int, float]]:
    """
    Optimized G_safe for a 100-state system using interval candidates.

    Input:
        P : current list of accepted criteria (each is a function X → {0,1})

    Output:
        best_interval : (u, v) defining the selected interval criterion
        best_score    : J = (complexity, |Resp|, Beta)
    """

    # --------------------------------------------------------
    # Step 1: Compute equivalence classes induced by P
    # --------------------------------------------------------
    # Two states are equivalent if they produce the same
    # bit-vector under all criteria in P.
    classes: Dict[Tuple[int, ...], List[int]] = {}

    for x in X:
        code = tuple(p(x) for p in P)  # encoding φ_P(x)
        classes.setdefault(code, []).append(x)

    equivalence_classes = list(classes.values())

    # --------------------------------------------------------
    # Step 2: Enumerate interval candidates and apply Accept
    # --------------------------------------------------------
    best_interval = None
    best_score = None

    # Enumerate the interval family H_int:
    # all pairs (u, v) with 0 ≤ u ≤ v ≤ 99
    for u in range(100):
        for v in range(u, 100):

            # ----- Responsibility-domain constraint -----
            resp = resp_set(u, v)
            if len(resp) > r:
                continue  # violates |Resp(p)| ≤ r

            # ----- Non-expansion (Beta) constraint -----
            beta = beta_for_interval(u, v, equivalence_classes)
            if beta > epsilon:
                continue  # violates Beta ≤ ε

            # ----- Complexity -----
            # Interval predicates are treated as atomic:
            complexity = 1

            # ----- J-score (lexicographic) -----
            score = (complexity, len(resp), beta)

            # Select lexicographically minimal J
            if best_score is None or score < best_score:
                best_score = score
                best_interval = (u, v)

    return best_interval, best_score

# ============================================================
# 5. EXAMPLE EXECUTION
# ============================================================

if __name__ == "__main__":
    # Initial criterion set is empty
    P = []

    interval, score = G_safe_interval(P)

    print("Selected interval criterion (u, v):", interval)
    print("J score (complexity, |Resp|, Beta):", score)
